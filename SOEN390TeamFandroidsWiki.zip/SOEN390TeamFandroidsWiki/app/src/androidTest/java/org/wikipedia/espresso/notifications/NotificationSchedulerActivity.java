package org.wikipedia.espresso.notifications;

public class NotificationSchedulerActivity {
}
