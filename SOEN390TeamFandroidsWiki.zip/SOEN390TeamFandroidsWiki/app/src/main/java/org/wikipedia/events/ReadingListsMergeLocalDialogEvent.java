package org.wikipedia.events;

public class ReadingListsMergeLocalDialogEvent {
}
