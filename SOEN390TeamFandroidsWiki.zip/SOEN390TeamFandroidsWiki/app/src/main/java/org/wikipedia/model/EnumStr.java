package org.wikipedia.model;

import android.support.annotation.NonNull;

public interface EnumStr {
    @NonNull String str();
}
