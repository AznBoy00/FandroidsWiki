package org.wikipedia.citation;

public enum CitationStyle {

    APA, MLA, IEEE, LATEX
}
